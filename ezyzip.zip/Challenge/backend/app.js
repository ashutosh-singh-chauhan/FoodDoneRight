import express from 'express'; 
import searchRouter from './routers/searchRouter.js';
import { PORT } from './constants.js';
import cors from 'cors';

const app = express();
app.use(cors())
// used to parse http req into req.body in your api
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

					
// confiure search-Router with express 
app.use('/api', searchRouter);
      
app.listen(PORT, () => {
  console.log(`listeining on https://localhost:${PORT}`);
})