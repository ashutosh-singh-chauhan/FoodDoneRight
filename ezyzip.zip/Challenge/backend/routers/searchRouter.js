import express from 'express';
import expressAsyncHandler from 'express-async-handler';
import data from '../asset.json' assert {type: "json"};
import { isInside, Point } from '../algo.js';
import { getPoints } from '../helper.js';

const searchRouter = express.Router();

searchRouter.post('/search', expressAsyncHandler(async (req, res) => {

  // Get the user provided lng & lat
  const lng = req.body.longitude;
  const lat = req.body.latitude;

  // find all the polygons
  const allPolygon = data.features.filter((feature) => 
    feature.geometry.type === 'Polygon');

  // find correct polygon name if point exists inside any
  for(let i=0; i<allPolygon.length; i++) {
    // check point lies in any polygon or not
    const isFound = isInside(getPoints(
      allPolygon[i].geometry.coordinates[0], Point), 
      allPolygon[i].geometry.coordinates[0].length,
      new Point(lat, lng)
    );
    if (isFound) {
      res.send({ 
        isInside: isFound, 
        name: allPolygon[i].properties.Name
      });
    }
  }
  res.send({ isInside: false, name: ''});
}))

export default searchRouter;