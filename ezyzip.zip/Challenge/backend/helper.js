export const getPoints = (arr, Point) => {
  let result = [];
  arr.map((p) => result.push(new Point(p[1], p[0])))
  return result;
}