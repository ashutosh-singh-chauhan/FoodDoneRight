import { useCallback, useState } from "react";
import { debounce } from 'lodash';

export const useHome = () => {
  // declare state variables
  const [value, setValue] = useState('');
  const [address, setAddress] = useState('');
  const [location, setLocation] = useState(null);

  // define necessary function handlers
  const searchHandler = useCallback(
    debounce((value) => {
      setAddress(value);
    }, 500),
    [],
  );

  // func to handle text change
  const handleSearchTextChange = (e) => {
    setValue(e.target.value);
    searchHandler(e.target.value)
  }

  // clear search text
  const handleClearText = () => {
    setValue('');
    setLocation(null);
  }

  // func to find the location name 
  const findAddress = async (payload) => {
    fetch('http://localhost:4000/api/search', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    })
    .then(response => response.json())
    .then(data => {
      setLocation(data);
    })
    .catch((error) => {
      console.error('Error:', error);
    });
  }

  // func to get lang & lat of given address
  const handleSubmit = async () => {
    fetch(`http://api.positionstack.com/v1/forward?access_key=c5418bee07ae7db28ae2dca5de7f7c36&limit=10&output=json&query=${address}`)
    .then((resp) => {
      resp.json().then((result) => {
        const payload = {
          longitude: result?.data?.[0]?.longitude,
          latitude: result?.data?.[0]?.latitude,
        }
        findAddress(payload);
      })
    })
    .catch(error => {
      console.log('Error : ', error);
    })
  }
  
  return {
    value,
    handleSearchTextChange,
    handleSubmit,
    location,
    handleClearText,
  }
}
